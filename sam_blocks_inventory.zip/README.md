S.A.M Blocks Inventory - Ready-to-run Flask project

Quick start:
1. python -m venv venv
2. venv\Scripts\activate  (Windows) or source venv/bin/activate (Linux/Mac)
3. pip install -r requirements.txt
4. flask --app app init-db
5. python app.py
6. Open http://127.0.0.1:5000

Default admin: username=admin password=admin123 (email: samventuresblocksinterlocks@gmail.com)

Force SQLite (quick note)
-------------------------
If you want to continue using the included local SQLite database and avoid any Postgres setup for now, you can force SQLite mode even when `DATABASE_URL` is present by setting the `FORCE_SQLITE` environment variable. Example for PowerShell:

```powershell
$env:FORCE_SQLITE = '1'
python app.py
# or: flask --app app run
```

Unset or remove `FORCE_SQLITE` to allow the app to use `DATABASE_URL` again.

Docker / Deployment
-------------------
This project supports running in Docker and can connect to a Postgres database using the `DATABASE_URL` environment variable.

Local Docker (Postgres + app)
1. Start services with docker-compose (requires Docker installed):

```powershell
docker compose up --build
```

2. The app will be available at http://127.0.0.1:5000. The Postgres container is reachable at `postgres://samuser:pass@localhost:5432/sam_blocks`.

Running the app container only
1. Build the image:

```powershell
docker build -t sam_blocks_inventory:latest .
```

2. Run the container (example using a hosted Postgres):

```powershell
# set DATABASE_URL for PowerShell
$env:DATABASE_URL = "postgresql://<user>:<pass>@<host>:5432/<db>"
docker run -e DATABASE_URL=$env:DATABASE_URL -p 5000:5000 sam_blocks_inventory:latest
```

Deploying to a platform
-----------------------
- Fly.io, Railway, Render and other providers accept a Dockerfile and a `DATABASE_URL` env var. Use the generated Dockerfile; set `DATABASE_URL` in the provider to point to a managed Postgres instance.
- For example, on Fly you can `fly launch` and set the Postgres addon; on Railway you can provision a Postgres plugin and set the `DATABASE_URL` automatically.

Migration reminder
------------------
If you have an existing `database.db` (SQLite) and want to migrate to Postgres, use the included `migrate_sqlite_to_postgres.py` script. Example (after setting `DATABASE_URL`):

```powershell
# dry-run to inspect counts
python migrate_sqlite_to_postgres.py --sqlite database.db --dry-run

# perform migration
python migrate_sqlite_to_postgres.py --sqlite database.db --pg $env:DATABASE_URL --yes
```

Post-migration: run the app with the `DATABASE_URL` and verify admin flows (login, products, audit, trips).

Troubleshooting
---------------
- If psycopg2 fails to install on Windows, use `psycopg2-binary` (already in requirements) or install build tools. The Dockerfile includes `libpq-dev` for building psycopg2 where required.
- If the app can't connect to Postgres, double-check `DATABASE_URL` and network rules (Docker `depends_on` delays startup but the DB may still be initializing). Use `docker compose logs db` to inspect Postgres logs.

If you'd like, I can also add a `fly.toml` or a quick `Dockerfile`-based GitHub Actions workflow to automate building and pushing the image.
CI / Build without Docker locally
--------------------------------
If you don't have Docker on your machine (the `docker` command not found), you have two good options:

1) Use GitHub Actions to build & push an image automatically (no Docker locally required).
	- The repo includes a workflow at `.github/workflows/docker-publish.yml` that builds the image and pushes to Docker Hub when you push to `main`.
	- Set the repository secrets `DOCKERHUB_USERNAME` and `DOCKERHUB_TOKEN` (a Docker Hub access token) in GitHub Settings → Secrets.
	- Optionally set `FLY_API_TOKEN` to allow the workflow to deploy to Fly automatically.

2) Install Docker Desktop (Windows) or use WSL2 + Docker Engine.
	- Docker Desktop: https://www.docker.com/products/docker-desktop
	- After installation, open Powershell and run `docker --version` to confirm.

If you want, I can help create the necessary GitHub secrets and show a sample `docker login` command to test pushing an image.#   s a m - b l o c k s - a n d - i n t e r l o c k s - i n v e n t o r y 
 
 